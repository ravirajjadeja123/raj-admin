
//enter the message you wish to be shown, including html tags
var message=msg

//enter a color name or hex to be used as the background color of the message
var backgroundcolor="#EEEEEE"

//enter 1 for always display, 2 for ONCE per browser session
var displaymode=1

//Set duration message should appear on screen, in seconds (10000=10 sec, 0=perpetual)
var displayduration=0

//enter 0 for non-flashing message, 1 for flashing
var flashmode=0
//if above is set to flashing, enter the flash-to color below
var flashtocolor="lightyellow"


///////////////do not edit below this line////////////////////////////////////////
var ie=document.all
var ieNOTopera=document.all&&navigator.userAgent.indexOf("Opera")==-1

function regenerate(){
window.location.reload()
}

function regenerate2(){
if (document.layers)
setTimeout("window.onresize=regenerate",400)
}

var which=0

function flash(){
	if (which==0){
		if (document.layers)
			topmsg_obj.bgColor=flashtocolor
		else
			topmsg_obj.style.backgroundColor=flashtocolor
			which=1
		}
	else{
		if (document.layers)
			topmsg_obj.bgColor=backgroundcolor
		else
			topmsg_obj.style.backgroundColor=backgroundcolor
			which=0
		}
}

if (ie||document.getElementById)
document.write('<div id="topmsg" style="position:absolute;visibility:hidden;width=100%" align="center">'+message+'</div>')

var topmsg_obj=ie? document.all.topmsg : document.getElementById? document.getElementById("topmsg") : document.topmsg

function positionit()
{
    var dsocleft=ie? document.body.scrollLeft : pageXOffset
    var dsoctop=ie? document.body.scrollTop : pageYOffset
    var window_width=ieNOTopera? document.body.clientWidth : window.innerWidth-20
    var window_height=ieNOTopera? document.body.clientHeight : window.innerHeight
      

    if(dsoctop<showdiv)
    {
      if(PAGE=='Paras')
        dsoctop ='850';
      if(PAGE=='mng_employees')
        dsoctop ='655';
      if(PAGE=='mng_employee_ded')
        dsoctop ='575';
      if(PAGE=='mng_employee_tran')
        dsoctop ='600';
      if(PAGE=='mng_employee_tran_ded')
        dsoctop ='619';
      if(PAGE=='mng_employee_att')
        dsoctop ='648';
      if(PAGE=='mng_employee_hours')
        dsoctop ='587';
    }
    
    if (ie||document.getElementById)
    {
    topmsg_obj.style.left=15//parseInt(dsocleft)+window_width/2-topmsg_obj.offsetWidth/2
    topmsg_obj.style.top=parseInt(dsoctop)+topmsg_obj.offsetHeight-20
    }
    else if (document.layers)
    {
    topmsg_obj.left=dsocleft+window_width/2-topmsg_obj.document.width/2
    topmsg_obj.top=dsoctop+topmsg_obj.document.height-5
    }
}

function setmessage()
{
   if (displaymode==2&&(!display_msg_or_not()))
   return
   if (document.layers)
   {
   topmsg_obj=new Layer(window.innerWidth)
   topmsg_obj.bgColor=backgroundcolor
   regenerate2()
   topmsg_obj.document.write(message)
   topmsg_obj.document.close()
   positionit()
   topmsg_obj.visibility="show"
   if (displayduration!=0)
   setTimeout("topmsg_obj.visibility='hide'",displayduration)
   }
   else
   {
   positionit()
   topmsg_obj.style.backgroundColor=backgroundcolor
   topmsg_obj.style.visibility="visible"
   if (displayduration!=0)
   setTimeout("topmsg_obj.style.visibility='hidden'",displayduration)
   }
   setInterval("positionit()",100)
   if (flashmode==1)
   setInterval("flash()",1000)
}
if (document.layers||ie||document.getElementById)
window.onload=setmessage