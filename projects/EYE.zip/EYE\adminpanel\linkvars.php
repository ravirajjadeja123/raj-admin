<?php 

$section_arr1=array(
    array ("TOUR","fa fa-circle-o","manage_tour.php"),
    array ("STOPS","fa fa-circle-o","manage_stops.php"),
);

$section_arr2=array(
    array ("ABOUT US","fa fa-circle-o","staticpage.php?slug=about-us"),
    array ("CONTACT US","fa fa-circle-o","staticpage.php?slug=contact-us"),
);

$section_arr3=array(
    array ("afd","fa fa-circle-o","staticpage.php?slug=afd"),
    array ("afsasdf","fa fa-circle-o","manage_asf.php"),
);

$HeadLinksArray = array (
    array("TOUR","fa fa-desktop",count($section_arr1),$section_arr1,""), 
    array("STATIC PAGES","fa fa-desktop",count($section_arr2),$section_arr2,""), 
    array("DONATION","fa fa-desktop",count($section_arr3),$section_arr3,""), 
);

?>