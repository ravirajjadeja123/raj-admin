<table width="100%" border="0" cellspacing="0" cellpadding="0">
      <tr>
        <td align="left" valign="top" bgcolor="#5d7282" height="3"></td>
      </tr>
      <tr>
        <td height="44" align="left" valign="top" class="footer_bg"><table width="98%" border="0" align="center" cellpadding="0" cellspacing="0">
          <tr>
            <td height="44" align="left" valign="middle" class="footer_text"></td>
            <td height="44" align="left" valign="middle" class="footer_text">&nbsp;</td>
            <td height="44" align="left" valign="middle" class="footer_text">&nbsp;</td>
          </tr>
        </table></td>
      </tr>
    </table>