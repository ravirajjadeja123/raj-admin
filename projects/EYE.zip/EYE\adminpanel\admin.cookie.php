<?php
  if(!strlen($_COOKIE["UsErOfAdMiN"]) > 0 )
    echo "<script language=javascript>window.parent.location.href='index.php'</script>";
?>
