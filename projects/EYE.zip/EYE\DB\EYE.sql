CREATE DATABASE DB_EYE; USE DB_EYE; 
  CREATE TABLE admin (id INT NOT NULL AUTO_INCREMENT,PRIMARY KEY(id), `username` TEXT(80) NOT NULL,`password` TEXT NOT NULL,`type` TEXT NOT NULL,`email` TEXT NOT NULL,`created` datetime NOT NULL,`updated` datetime NOT NULL,`status` int(11) NOT NULL); 
INSERT INTO `admin` (`username`, `password`, `type`, `email`, `created`, `status`) VALUES
("admin", "21232f297a57a5a743894a0e4a801fc3", "admin", "admin@gmail.com", "2018-03-17 15:30:41", 1);

CREATE TABLE IF NOT EXISTS staticpage (id INT NOT NULL AUTO_INCREMENT, 
  PRIMARY KEY(id),
  page_header TEXT NOT NULL,
  image_path TEXT NOT NULL,
  content TEXT NOT NULL,
  meta_keywords TEXT NOT NULL,
  meta_discription TEXT NOT NULL,
  title TEXT NOT NULL,
  alt TEXT NOT NULL,display_order TEXT NOT NULL);  INSERT INTO staticpage (id,title,content,alt)VALUES (NULL ,'ABOUT US','','about-us'); CREATE TABLE tour( id INT NOT NULL AUTO_INCREMENT, PRIMARY KEY(id), tour)name TEXT NOT NULL  ,display_order INT ); INSERT INTO staticpage (id,title,content,alt)VALUES (NULL ,'afd','','afd'); INSERT INTO staticpage (id,title,content,alt)VALUES (NULL ,'CONTACT US','','contact-us');